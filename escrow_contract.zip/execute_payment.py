from algosdk.future.transaction import LogicSigTransaction, PaymentTxn
from pyteal import *
from escrow_approval import escrow_contract
from algod_config import algod_client
from algosdk import transaction

compiled_teal = compileTeal(escrow_contract(), mode=Mode.Signature, version=6)
lsig_compiled = algod_client.compile(compiled_teal)
lsig = transaction.LogicSigAccount(lsig_compiled["result"])

params = algod_client.suggested_params()
txn = PaymentTxn(lsig.address(), params, "RECEIVER_ALGORAND_ADDRESS", 1000000)
lstx = LogicSigTransaction(txn, lsig)
algod_client.send_transaction(lstx)
