# Algorand Escrow Smart Contract

This project implements a simple escrow smart contract using PyTEAL for the Algorand blockchain. The contract releases funds only if specific conditions are met.

## Files

- `escrow_approval.py` - PyTEAL smart contract logic.
- `compile.py` - Compiles PyTEAL code to TEAL.
- `algod_config.py` - Algorand node client configuration.
- `fund_escrow.py` - Script to fund the escrow contract address.
- `execute_payment.py` - Script to execute the escrow payment.
- `escrow_approval.teal` - Compiled TEAL smart contract.

## Setup

1. Install dependencies:

```bash
pip install pyteal py-algorand-sdk
```

2. Replace placeholders in files:
   - `RECEIVER_ALGORAND_ADDRESS` in `escrow_approval.py` and `execute_payment.py`.
   - Algorand node token and address in `algod_config.py`.

3. Compile the smart contract:

```bash
python compile.py
```

4. Fund the escrow account:

```bash
python fund_escrow.py
```

5. Execute the payment if conditions are met:

```bash
python execute_payment.py
```

## Notes

- Ensure you have access to an Algorand node (local sandbox or testnet).
- Modify parameters as needed for your use case.
