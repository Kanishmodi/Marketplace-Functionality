from algosdk import account, transaction
from algosdk.future.transaction import PaymentTxn
from pyteal import *
from escrow_approval import escrow_contract
from algod_config import algod_client

private_key, sender = account.generate_account()

compiled_teal = compileTeal(escrow_contract(), mode=Mode.Signature, version=6)
lsig_compiled = algod_client.compile(compiled_teal)
lsig = transaction.LogicSigAccount(lsig_compiled["result"])

params = algod_client.suggested_params()
txn = PaymentTxn(sender, params, lsig.address(), 2000000)
signed_txn = txn.sign(private_key)
algod_client.send_transaction(signed_txn)
