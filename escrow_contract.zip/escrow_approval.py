from pyteal import *

def escrow_contract():
    receiver = Addr("RECEIVER_ALGORAND_ADDRESS")
    amount = Int(1000000)
    condition = And(
        Txn.type_enum() == TxnType.Payment,
        Txn.receiver() == receiver,
        Txn.amount() == amount,
        Txn.close_remainder_to() == Global.zero_address()
    )
    return condition

if __name__ == "__main__":
    print(compileTeal(escrow_contract(), mode=Mode.Signature, version=6))
