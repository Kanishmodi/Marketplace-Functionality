from algosdk.v2client import algod

algod_token = "YOUR_ALGOD_TOKEN"
algod_address = "http://localhost:4001"

algod_client = algod.AlgodClient(algod_token, algod_address)
