from pyteal import *
from escrow_approval import escrow_contract

compiled_teal = compileTeal(escrow_contract(), mode=Mode.Signature, version=6)

with open("escrow_approval.teal", "w") as f:
    f.write(compiled_teal)
